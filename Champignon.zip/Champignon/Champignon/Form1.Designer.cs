﻿namespace Champignon
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.lblNameLeft = new System.Windows.Forms.Label();
            this.Label5 = new System.Windows.Forms.Label();
            this.lblLevelLeft = new System.Windows.Forms.Label();
            this.healthBarLeft = new System.Windows.Forms.ProgressBar();
            this.healthBarRight = new System.Windows.Forms.ProgressBar();
            this.lblLevelRight = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lblNameRight = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.btnLeftAttack = new System.Windows.Forms.Button();
            this.btnRightAttack = new System.Windows.Forms.Button();
            this.btnLeftLevelUp = new System.Windows.Forms.Button();
            this.lblLeftHealth = new System.Windows.Forms.Label();
            this.lblRightHealth = new System.Windows.Forms.Label();
            this.btnRightLevelUp = new System.Windows.Forms.Button();
            this.lblsuperSaiyan = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(49, 17);
            this.label1.TabIndex = 1;
            this.label1.Text = "Name:";
            // 
            // lblNameLeft
            // 
            this.lblNameLeft.AutoSize = true;
            this.lblNameLeft.Location = new System.Drawing.Point(86, 13);
            this.lblNameLeft.Name = "lblNameLeft";
            this.lblNameLeft.Size = new System.Drawing.Size(46, 17);
            this.lblNameLeft.TabIndex = 2;
            this.lblNameLeft.Text = "label2";
            // 
            // Label5
            // 
            this.Label5.AutoSize = true;
            this.Label5.Location = new System.Drawing.Point(15, 44);
            this.Label5.Name = "Label5";
            this.Label5.Size = new System.Drawing.Size(46, 17);
            this.Label5.TabIndex = 3;
            this.Label5.Text = "Level:";
            // 
            // lblLevelLeft
            // 
            this.lblLevelLeft.AutoSize = true;
            this.lblLevelLeft.Location = new System.Drawing.Point(86, 44);
            this.lblLevelLeft.Name = "lblLevelLeft";
            this.lblLevelLeft.Size = new System.Drawing.Size(46, 17);
            this.lblLevelLeft.TabIndex = 4;
            this.lblLevelLeft.Text = "label2";
            // 
            // healthBarLeft
            // 
            this.healthBarLeft.Location = new System.Drawing.Point(15, 73);
            this.healthBarLeft.MarqueeAnimationSpeed = 500;
            this.healthBarLeft.Maximum = 200;
            this.healthBarLeft.Name = "healthBarLeft";
            this.healthBarLeft.Size = new System.Drawing.Size(161, 23);
            this.healthBarLeft.Style = System.Windows.Forms.ProgressBarStyle.Continuous;
            this.healthBarLeft.TabIndex = 5;
            // 
            // healthBarRight
            // 
            this.healthBarRight.Location = new System.Drawing.Point(810, 73);
            this.healthBarRight.MarqueeAnimationSpeed = 500;
            this.healthBarRight.Maximum = 200;
            this.healthBarRight.Name = "healthBarRight";
            this.healthBarRight.Size = new System.Drawing.Size(161, 23);
            this.healthBarRight.Style = System.Windows.Forms.ProgressBarStyle.Continuous;
            this.healthBarRight.TabIndex = 10;
            // 
            // lblLevelRight
            // 
            this.lblLevelRight.AutoSize = true;
            this.lblLevelRight.Location = new System.Drawing.Point(874, 44);
            this.lblLevelRight.Name = "lblLevelRight";
            this.lblLevelRight.Size = new System.Drawing.Size(46, 17);
            this.lblLevelRight.TabIndex = 9;
            this.lblLevelRight.Text = "label2";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(807, 44);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(46, 17);
            this.label3.TabIndex = 8;
            this.label3.Text = "Level:";
            // 
            // lblNameRight
            // 
            this.lblNameRight.AutoSize = true;
            this.lblNameRight.Location = new System.Drawing.Point(874, 13);
            this.lblNameRight.Name = "lblNameRight";
            this.lblNameRight.Size = new System.Drawing.Size(46, 17);
            this.lblNameRight.TabIndex = 7;
            this.lblNameRight.Text = "label2";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(807, 13);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(49, 17);
            this.label6.TabIndex = 6;
            this.label6.Text = "Name:";
            // 
            // btnLeftAttack
            // 
            this.btnLeftAttack.Location = new System.Drawing.Point(15, 304);
            this.btnLeftAttack.Name = "btnLeftAttack";
            this.btnLeftAttack.Size = new System.Drawing.Size(164, 43);
            this.btnLeftAttack.TabIndex = 13;
            this.btnLeftAttack.Text = "Attack!";
            this.btnLeftAttack.UseVisualStyleBackColor = true;
            this.btnLeftAttack.Click += new System.EventHandler(this.btnLeftAttack_Click);
            // 
            // btnRightAttack
            // 
            this.btnRightAttack.Location = new System.Drawing.Point(810, 304);
            this.btnRightAttack.Name = "btnRightAttack";
            this.btnRightAttack.Size = new System.Drawing.Size(164, 43);
            this.btnRightAttack.TabIndex = 14;
            this.btnRightAttack.Text = "Attack!";
            this.btnRightAttack.UseVisualStyleBackColor = true;
            this.btnRightAttack.Click += new System.EventHandler(this.btnRightAttack_Click);
            // 
            // btnLeftLevelUp
            // 
            this.btnLeftLevelUp.Location = new System.Drawing.Point(15, 354);
            this.btnLeftLevelUp.Name = "btnLeftLevelUp";
            this.btnLeftLevelUp.Size = new System.Drawing.Size(164, 45);
            this.btnLeftLevelUp.TabIndex = 15;
            this.btnLeftLevelUp.Text = "Level up!";
            this.btnLeftLevelUp.UseVisualStyleBackColor = true;
            this.btnLeftLevelUp.Click += new System.EventHandler(this.btnLeftLevelUp_Click);
            // 
            // lblLeftHealth
            // 
            this.lblLeftHealth.AutoSize = true;
            this.lblLeftHealth.BackColor = System.Drawing.Color.White;
            this.lblLeftHealth.Location = new System.Drawing.Point(70, 76);
            this.lblLeftHealth.Name = "lblLeftHealth";
            this.lblLeftHealth.Size = new System.Drawing.Size(46, 17);
            this.lblLeftHealth.TabIndex = 16;
            this.lblLeftHealth.Text = "label2";
            // 
            // lblRightHealth
            // 
            this.lblRightHealth.AutoSize = true;
            this.lblRightHealth.Location = new System.Drawing.Point(869, 76);
            this.lblRightHealth.Name = "lblRightHealth";
            this.lblRightHealth.Size = new System.Drawing.Size(46, 17);
            this.lblRightHealth.TabIndex = 17;
            this.lblRightHealth.Text = "label2";
            // 
            // btnRightLevelUp
            // 
            this.btnRightLevelUp.Location = new System.Drawing.Point(810, 354);
            this.btnRightLevelUp.Name = "btnRightLevelUp";
            this.btnRightLevelUp.Size = new System.Drawing.Size(164, 45);
            this.btnRightLevelUp.TabIndex = 18;
            this.btnRightLevelUp.Text = "Level up!";
            this.btnRightLevelUp.UseVisualStyleBackColor = true;
            this.btnRightLevelUp.Click += new System.EventHandler(this.btnRightLevelUp_Click);
            // 
            // lblsuperSaiyan
            // 
            this.lblsuperSaiyan.AutoSize = true;
            this.lblsuperSaiyan.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblsuperSaiyan.ForeColor = System.Drawing.Color.Gold;
            this.lblsuperSaiyan.Location = new System.Drawing.Point(229, 434);
            this.lblsuperSaiyan.Name = "lblsuperSaiyan";
            this.lblsuperSaiyan.Size = new System.Drawing.Size(0, 58);
            this.lblsuperSaiyan.TabIndex = 19;
            this.lblsuperSaiyan.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::Champignon.Properties.Resources.Annex___Flynn__Errol__Adventures_of_Robin_Hood__The__02;
            this.pictureBox2.Location = new System.Drawing.Point(810, 102);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(164, 196);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 12;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Champignon.Properties.Resources._219596_large;
            this.pictureBox1.Location = new System.Drawing.Point(15, 102);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(164, 196);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 11;
            this.pictureBox1.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(986, 622);
            this.Controls.Add(this.lblsuperSaiyan);
            this.Controls.Add(this.btnRightLevelUp);
            this.Controls.Add(this.lblRightHealth);
            this.Controls.Add(this.lblLeftHealth);
            this.Controls.Add(this.btnLeftLevelUp);
            this.Controls.Add(this.btnRightAttack);
            this.Controls.Add(this.btnLeftAttack);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.healthBarRight);
            this.Controls.Add(this.lblLevelRight);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.lblNameRight);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.healthBarLeft);
            this.Controls.Add(this.lblLevelLeft);
            this.Controls.Add(this.Label5);
            this.Controls.Add(this.lblNameLeft);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblNameLeft;
        private System.Windows.Forms.Label Label5;
        private System.Windows.Forms.Label lblLevelLeft;
        private System.Windows.Forms.ProgressBar healthBarLeft;
        private System.Windows.Forms.ProgressBar healthBarRight;
        private System.Windows.Forms.Label lblLevelRight;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblNameRight;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button btnLeftAttack;
        private System.Windows.Forms.Button btnRightAttack;
        private System.Windows.Forms.Button btnLeftLevelUp;
        public System.Windows.Forms.Label lblLeftHealth;
        private System.Windows.Forms.Label lblRightHealth;
        private System.Windows.Forms.Button btnRightLevelUp;
        private System.Windows.Forms.Label lblsuperSaiyan;
    }
}

